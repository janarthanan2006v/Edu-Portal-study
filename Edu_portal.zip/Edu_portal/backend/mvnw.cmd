@REM ----------------------------------------------------------------------------
@REM Licensed to the Apache Software Foundation (ASF)
@REM Maven Wrapper startup batch script, version 3.2.0
@REM ----------------------------------------------------------------------------

@IF "%__MVNW_ARG0_NAME__%"=="" (SET "BASE_DIR=%~dp0")

@SET MAVEN_PROJECTBASEDIR=%BASE_DIR%

@IF NOT "%MAVEN_BASEDIR%"=="" (SET "MAVEN_PROJECTBASEDIR=%MAVEN_BASEDIR%")

@SET WRAPPER_PROPERTIES="%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.properties"

@SET DOWNLOAD_URL=
@FOR /F "usebackq tokens=1,2 delims==" %%a IN (%WRAPPER_PROPERTIES%) DO (
    @IF "%%a"=="distributionUrl" (SET "DOWNLOAD_URL=%%b")
)

@IF "%DOWNLOAD_URL%"=="" (
    echo [ERROR] Cannot read distributionUrl from .mvn\wrapper\maven-wrapper.properties
    exit /B 1
)

@SET MAVEN_USER_HOME=%USERPROFILE%\.m2
@SET MAVEN_HOME=%MAVEN_USER_HOME%\wrapper\dists

@FOR %%i IN ("%DOWNLOAD_URL%") DO (
    @SET DIST_FILENAME=%%~ni
)

@SET DIST_DIR=%MAVEN_HOME%\%DIST_FILENAME%

@IF EXIST "%DIST_DIR%" GOTO run_maven

echo [INFO] Downloading Maven from %DOWNLOAD_URL%
@IF NOT EXIST "%MAVEN_HOME%" (MKDIR "%MAVEN_HOME%")
@SET DIST_ZIP=%MAVEN_HOME%\%DIST_FILENAME%.zip
@powershell -Command "& { [System.Net.WebClient]::new().DownloadFile('%DOWNLOAD_URL%', '%DIST_ZIP%') }"
@IF NOT EXIST "%DIST_ZIP%" (
    echo [ERROR] Failed to download Maven distribution.
    exit /B 1
)
@powershell -Command "& { Expand-Archive -Path '%DIST_ZIP%' -DestinationPath '%MAVEN_HOME%' -Force }"
@DEL "%DIST_ZIP%"
@FOR /D %%d IN ("%MAVEN_HOME%\apache-maven*") DO (SET "DIST_DIR=%%d")
echo [INFO] Maven downloaded to %DIST_DIR%

:run_maven
@SET "M2_HOME=%DIST_DIR%"
@SET "PATH=%M2_HOME%\bin;%PATH%"
@mvn %*
