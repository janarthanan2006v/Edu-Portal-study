package com.prince.materialportal.dto;

public class MaterialSearchResponse {
    private String subjectName;
    private String department;
    private String courseYear;
    private String semester;
    private String driveLink;

    public MaterialSearchResponse() {}

    public MaterialSearchResponse(String subjectName, String department, String courseYear, String semester, String driveLink) {
        this.subjectName = subjectName;
        this.department = department;
        this.courseYear = courseYear;
        this.semester = semester;
        this.driveLink = driveLink;
    }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getCourseYear() { return courseYear; }
    public void setCourseYear(String courseYear) { this.courseYear = courseYear; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    public String getDriveLink() { return driveLink; }
    public void setDriveLink(String driveLink) { this.driveLink = driveLink; }
}
