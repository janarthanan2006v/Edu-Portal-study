package com.prince.materialportal.util;

import com.prince.materialportal.dto.ApiResponse;

public class ResponseBuilder {
    public static <T> ApiResponse<T> buildSuccess(String message, T data) {
        return new ApiResponse<>(true, message, data);
    }

    public static <T> ApiResponse<T> buildError(String message) {
        return new ApiResponse<>(false, message, null);
    }
}
