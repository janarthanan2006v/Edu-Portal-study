package com.prince.materialportal.controller;

import com.prince.materialportal.dto.*;
import com.prince.materialportal.entity.Material;
import com.prince.materialportal.service.MaterialService;
import com.prince.materialportal.util.ResponseBuilder;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/faculty/materials")
@RequiredArgsConstructor
public class FacultyMaterialController {

    private final MaterialService materialService;

    @PostMapping
    public ResponseEntity<ApiResponse<Material>> createMaterial(@Valid @RequestBody MaterialCreateRequest request) {
        Material created = materialService.createMaterial(request);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Material created successfully", created));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Material>> updateMaterial(
            @PathVariable Long id,
            @Valid @RequestBody MaterialUpdateRequest request
    ) {
        Material updated = materialService.updateMaterial(id, request);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Material updated successfully", updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteMaterial(@PathVariable Long id) {
        materialService.deleteMaterial(id);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Material deleted successfully", null));
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<Material>>> getAllMaterials() {
        List<Material> materials = materialService.getAllMaterials();
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Materials retrieved successfully", materials));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Material>> getMaterialById(@PathVariable Long id) {
        Material material = materialService.getMaterialById(id);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Material retrieved successfully", material));
    }
}
