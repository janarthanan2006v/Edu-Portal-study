package com.prince.materialportal.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class MaterialUpdateRequest {
    @NotBlank(message = "Subject name is required.")
    private String subjectName;

    @NotBlank(message = "Department is required.")
    private String department;

    @NotBlank(message = "Course year is required.")
    private String courseYear;

    private String sem1;
    private String sem2;

    @NotNull(message = "Active status is required.")
    private Boolean activeStatus;

    public MaterialUpdateRequest() {}

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getCourseYear() { return courseYear; }
    public void setCourseYear(String courseYear) { this.courseYear = courseYear; }
    public String getSem1() { return sem1; }
    public void setSem1(String sem1) { this.sem1 = sem1; }
    public String getSem2() { return sem2; }
    public void setSem2(String sem2) { this.sem2 = sem2; }
    public Boolean getActiveStatus() { return activeStatus; }
    public void setActiveStatus(Boolean activeStatus) { this.activeStatus = activeStatus; }
}
