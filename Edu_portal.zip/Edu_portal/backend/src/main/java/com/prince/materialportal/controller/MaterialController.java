package com.prince.materialportal.controller;

import com.prince.materialportal.dto.ApiResponse;
import com.prince.materialportal.dto.MaterialSearchResponse;
import com.prince.materialportal.service.MaterialService;
import com.prince.materialportal.util.ResponseBuilder;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/materials")
@RequiredArgsConstructor
public class MaterialController {

    private final MaterialService materialService;

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<MaterialSearchResponse>> search(
            @RequestParam String subjectName,
            @RequestParam String semester
    ) {
        MaterialSearchResponse response = materialService.searchMaterial(subjectName, semester);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Material found successfully", response));
    }
}
