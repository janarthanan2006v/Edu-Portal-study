package com.prince.materialportal.controller;

import com.prince.materialportal.dto.ApiResponse;
import com.prince.materialportal.dto.LoginRequest;
import com.prince.materialportal.dto.LoginResponse;
import com.prince.materialportal.service.AuthService;
import com.prince.materialportal.util.ResponseBuilder;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest request) {
        LoginResponse response = authService.login(request);
        return ResponseEntity.ok(ResponseBuilder.buildSuccess("Login successful", response));
    }
}
