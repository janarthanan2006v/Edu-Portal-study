package com.prince.materialportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaterialPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(MaterialPortalApplication.class, args);
    }
}
