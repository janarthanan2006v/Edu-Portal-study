package com.prince.materialportal.service;

import com.prince.materialportal.dto.*;
import com.prince.materialportal.entity.Material;
import com.prince.materialportal.exception.InvalidRequestException;
import com.prince.materialportal.exception.ResourceNotFoundException;
import com.prince.materialportal.repository.MaterialRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MaterialService {

    private final MaterialRepository materialRepository;

    public MaterialService(MaterialRepository materialRepository) {
        this.materialRepository = materialRepository;
    }

    public MaterialSearchResponse searchMaterial(String subjectName, String semester) {
        if (subjectName == null || subjectName.trim().isEmpty()) {
            throw new InvalidRequestException("Subject name is required.");
        }
        if (semester == null || semester.trim().isEmpty()) {
            throw new InvalidRequestException("Semester is required.");
        }
        if (!semester.equalsIgnoreCase("Sem1") && !semester.equalsIgnoreCase("Sem2")) {
            throw new InvalidRequestException("Invalid semester. Allowed values are Sem1 and Sem2.");
        }

        Material material = materialRepository.findBySubjectNameIgnoreCaseAndActiveStatusTrue(subjectName.trim())
                .orElseThrow(() -> new ResourceNotFoundException("Material not found for the given subject."));

        String driveLink = semester.equalsIgnoreCase("Sem1") ? material.getSem1() : material.getSem2();
        if (driveLink == null || driveLink.trim().isEmpty()) {
            throw new ResourceNotFoundException("Material link not available for this semester.");
        }

        return new MaterialSearchResponse(
                material.getSubjectName(),
                material.getDepartment(),
                material.getCourseYear(),
                semester,
                driveLink
        );
    }

    public List<Material> getAllMaterials() {
        return materialRepository.findAll();
    }

    public Material getMaterialById(Long id) {
        return materialRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Material not found with id: " + id));
    }

    @Transactional
    public Material createMaterial(MaterialCreateRequest request) {
        Material material = new Material();
        material.setSubjectName(request.getSubjectName());
        material.setDepartment(request.getDepartment());
        material.setCourseYear(request.getCourseYear());
        material.setSem1(request.getSem1());
        material.setSem2(request.getSem2());
        material.setActiveStatus(request.getActiveStatus());
        return materialRepository.save(material);
    }

    @Transactional
    public Material updateMaterial(Long id, MaterialUpdateRequest request) {
        Material material = getMaterialById(id);
        material.setSubjectName(request.getSubjectName());
        material.setDepartment(request.getDepartment());
        material.setCourseYear(request.getCourseYear());
        material.setSem1(request.getSem1());
        material.setSem2(request.getSem2());
        material.setActiveStatus(request.getActiveStatus());
        return materialRepository.save(material);
    }

    @Transactional
    public void deleteMaterial(Long id) {
        Material material = getMaterialById(id);
        materialRepository.delete(material);
    }
}
