package com.prince.materialportal.repository;

import com.prince.materialportal.entity.Material;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface MaterialRepository extends JpaRepository<Material, Long> {
    Optional<Material> findBySubjectNameIgnoreCaseAndActiveStatusTrue(String subjectName);
    List<Material> findByDepartmentIgnoreCaseAndActiveStatusTrue(String department);
    List<Material> findBySubjectNameContainingIgnoreCase(String subjectName);
}
