-- Insert default roles
INSERT IGNORE INTO roles (id, name) VALUES (1, 'ROLE_STUDENT');
INSERT IGNORE INTO roles (id, name) VALUES (2, 'ROLE_FACULTY');

-- Insert default users (BCrypt hash for 'password')
INSERT IGNORE INTO users (id, username, password) VALUES (1, 'psvpec.2025.students@gmail.com', '$2a$10$Y50UaMFOxteibQEYOFo89uA1KkK/FfGfevM53f0S96v2yG80f282G');
INSERT IGNORE INTO users (id, username, password) VALUES (2, 'psvpec.2025.staffs@gmail.com', '$2a$10$Y50UaMFOxteibQEYOFo89uA1KkK/FfGfevM53f0S96v2yG80f282G');

-- Map users to roles
INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (1, 1);
INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (2, 2);

-- Insert sample Material record with Sem1 and Sem2 drive links
INSERT IGNORE INTO Material (id, subject_name, department, course_year, Sem1, Sem2, active_status, created_at, updated_at) 
VALUES (1, 'Java Programming', 'Information Technology', 'Year 1', 
        'https://drive.google.com/drive/folders/17fUS7YzfL001mcFGnRAUtTWihcz7F_qW?usp=drive_link', 
        'https://drive.google.com/drive/folders/1IVVzJ_SJ7XwF8mNQWitE9ALsOFn_Sted?usp=drive_link', 
        true, NOW(), NOW());
