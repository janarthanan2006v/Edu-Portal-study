# Prince Study Material Portal — Agile Assembly

A full-stack study material portal built with Spring Boot (backend) and HTML/JavaScript (frontend).

---

## Prerequisites

| Tool      | Minimum Version |
|-----------|----------------|
| Java      | 17             |
| Maven     | 3.8+           |
| MySQL     | 8.0+           |

---

## Step 1 — MySQL Database Setup

Open your MySQL client and run:

```sql
CREATE DATABASE prince_material_portal;
```

> Default credentials expected by the app: **username** `root`, **password** `root`.
> You can change these in `backend/src/main/resources/application.properties`.

---

## Step 2 — Run the Backend (Spring Boot)

```powershell
cd backend
.\mvnw.cmd spring-boot:run
```

> `mvnw.cmd` is the **Maven Wrapper** — it auto-downloads Maven on first run so you don't need Maven installed globally.

The server starts at: **http://localhost:8080**

Swagger API docs: **http://localhost:8080/swagger-ui/index.html**

> On first run, `schema.sql` creates the tables and `data.sql` seeds the default users and sample material automatically.

**Default Login Credentials**

| Role    | Username                           | Password   |
|---------|------------------------------------|------------|
| Student | psvpec.2025.students@gmail.com     | password   |
| Faculty | psvpec.2025.staffs@gmail.com       | password   |

---

## Step 3 — Run the Frontend

Open `frontend/index.html` using **VS Code Live Server** (right-click → *Open with Live Server*).

It will launch at: **http://127.0.0.1:5500**

> Live Server is required so that `fetch()` API calls work correctly (CORS is configured for port 5500 and 3000).

---

## Project Structure

```
Edu_portal/
├── backend/                        ← Spring Boot application
│   ├── pom.xml                     ← Maven build + run config
│   └── src/main/
│       ├── java/com/prince/materialportal/
│       │   ├── MaterialPortalApplication.java
│       │   ├── config/             (Security, JWT, CORS, Swagger)
│       │   ├── controller/         (AuthController, MaterialController, FacultyMaterialController)
│       │   ├── dto/                (Request/Response models)
│       │   ├── entity/             (User, Role, Material)
│       │   ├── exception/          (GlobalExceptionHandler)
│       │   ├── repository/         (UserRepository, MaterialRepository)
│       │   ├── service/            (AuthService, MaterialService, JwtService)
│       │   └── util/               (ResponseBuilder, DateUtil)
│       └── resources/
│           ├── application.properties
│           ├── schema.sql          ← Auto-creates DB tables
│           └── data.sql            ← Seeds default users and material
└── frontend/
    ├── index.html                  ← Main portal UI
    ├── script.js                   ← API logic (login, search, CRUD)
    ├── Prince-background-img.jpg
    └── prince-header-img.png
```

---

## Quick Command Reference

```powershell
# Backend — compile only
cd backend; .\mvnw.cmd clean compile

# Backend — run the application  ← USE THIS
cd backend; .\mvnw.cmd spring-boot:run

# Backend — build a runnable JAR
cd backend; .\mvnw.cmd clean package
java -jar target/material-portal-0.0.1-SNAPSHOT.jar
```
